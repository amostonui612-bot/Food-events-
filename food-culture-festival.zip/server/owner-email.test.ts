import { describe, expect, it } from "vitest";
import { ENV } from "./_core/env";

describe("Owner Email Configuration", () => {
  it("should have owner email configured", () => {
    expect(ENV.ownerEmail).toBeDefined();
    expect(ENV.ownerEmail).toBeTruthy();
  });

  it("should be a valid email format", () => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    expect(ENV.ownerEmail).toMatch(emailRegex);
  });

  it("should match the configured email", () => {
    expect(ENV.ownerEmail).toBe("w9282108@gmail.com");
  });
});
