import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router, adminProcedure } from "./_core/trpc";
import { z } from "zod";
import { getDb } from "./db";
import { vendors, menuItems, tickets, groupMembers, orders } from "../drizzle/schema";
import { getVendorByUserId, getAllVendors, getVendorById, getMenuItemsByVendorId, getAllMenuItems, getTicketByCode, getTicketsByUserId } from "./db";
import { nanoid } from "nanoid";
import { notifyOwner } from "./_core/notification";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Vendor procedures
  vendor: router({
    register: protectedProcedure
      .input(z.object({
        businessName: z.string().min(1),
        cuisine: z.string().min(1),
        description: z.string().optional(),
        image: z.string().optional(),
        contactEmail: z.string().email(),
        contactPhone: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // Check if vendor already exists
        const existing = await getVendorByUserId(ctx.user.id);
        if (existing) throw new Error("Vendor profile already exists");

        const result = await db.insert(vendors).values({
          userId: ctx.user.id,
          businessName: input.businessName,
          cuisine: input.cuisine,
          description: input.description,
          image: input.image,
          contactEmail: input.contactEmail,
          contactPhone: input.contactPhone,
          status: "pending",
        });

        // Notify owner of new vendor registration
        await notifyOwner({
          title: "New Vendor Registration",
          content: `${input.businessName} (${input.cuisine} cuisine) has registered and is pending approval.`,
        });

        return { success: true };
      }),

    getProfile: protectedProcedure.query(async ({ ctx }) => {
      return await getVendorByUserId(ctx.user.id);
    }),

    updateProfile: protectedProcedure
      .input(z.object({
        businessName: z.string().min(1).optional(),
        description: z.string().optional(),
        image: z.string().optional(),
        contactPhone: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const vendor = await getVendorByUserId(ctx.user.id);
        if (!vendor) throw new Error("Vendor profile not found");

        await db.update(vendors).set(input).where(eq(vendors.id, vendor.id));
        return { success: true };
      }),

    getAllApproved: publicProcedure.query(async () => {
      return await getAllVendors("approved");
    }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await getVendorById(input.id);
      }),
  }),

  // Menu item procedures
  menu: router({
    addItem: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        description: z.string().optional(),
        price: z.string().regex(/^\d+(\.\d{2})?$/),
        image: z.string().optional(),
        dietary: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const vendor = await getVendorByUserId(ctx.user.id);
        if (!vendor) throw new Error("Vendor profile not found");

        await db.insert(menuItems).values({
          vendorId: vendor.id,
          name: input.name,
          description: input.description,
          price: input.price,
          image: input.image,
          dietary: input.dietary,
        });

        return { success: true };
      }),

    getByVendor: publicProcedure
      .input(z.object({ vendorId: z.number() }))
      .query(async ({ input }) => {
        return await getMenuItemsByVendorId(input.vendorId);
      }),

    getAll: publicProcedure.query(async () => {
      return await getAllMenuItems();
    }),

    deleteItem: protectedProcedure
      .input(z.object({ itemId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const vendor = await getVendorByUserId(ctx.user.id);
        if (!vendor) throw new Error("Vendor profile not found");

        const item = await db.select().from(menuItems).where(eq(menuItems.id, input.itemId)).limit(1);
        if (!item.length || item[0].vendorId !== vendor.id) {
          throw new Error("Unauthorized");
        }

        await db.delete(menuItems).where(eq(menuItems.id, input.itemId));
        return { success: true };
      }),
  }),

  // Ticket procedures
  ticket: router({
    create: publicProcedure
      .input(z.object({
        ticketType: z.enum(["single", "group"]),
        groupSize: z.number().min(1).optional(),
        groupLeaderName: z.string().optional(),
        memberNames: z.array(z.string()).optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const ticketCode = nanoid(12);
        let price = 20; // Default single ticket price

        // Calculate group discount
        if (input.ticketType === "group" && input.groupSize) {
          if (input.groupSize >= 10) price = 10;
          else if (input.groupSize >= 5) price = 12;
          else if (input.groupSize >= 2) price = 14;
        }

        const totalPrice = (price * (input.groupSize || 1)).toString();

        const result = await db.insert(tickets).values({
          ticketCode,
          ticketType: input.ticketType,
          groupSize: input.groupSize || 1,
          price: totalPrice,
          userId: ctx.user?.id,
        });

        // Add group members if provided
        if (input.ticketType === "group" && input.memberNames && input.memberNames.length > 0) {
          const ticketId = (result as any).insertId;
          for (const memberName of input.memberNames) {
            await db.insert(groupMembers).values({
              ticketId,
              memberName,
            });
          }
        }

        // Notify owner of ticket sale
        await notifyOwner({
          title: "New Ticket Sale",
          content: `${input.ticketType === "group" ? `Group ticket (${input.groupSize} people)` : "Single ticket"} purchased for $${totalPrice}`,
        });

        return { ticketCode, price: totalPrice };
      }),

    getByCode: publicProcedure
      .input(z.object({ code: z.string() }))
      .query(async ({ input }) => {
        return await getTicketByCode(input.code);
      }),

    getUserTickets: protectedProcedure.query(async ({ ctx }) => {
      return await getTicketsByUserId(ctx.user.id);
    }),

    scan: publicProcedure
      .input(z.object({ ticketCode: z.string() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const ticket = await getTicketByCode(input.ticketCode);
        if (!ticket) throw new Error("Ticket not found");
        if (ticket.status !== "active") throw new Error("Ticket already used or cancelled");

        await db.update(tickets).set({
          status: "used",
          scannedAt: new Date(),
        }).where(eq(tickets.id, ticket.id));

        return { success: true, ticket };
      }),
  }),

  // Admin procedures
  admin: router({
    getVendors: adminProcedure.query(async () => {
      return await getAllVendors();
    }),

    approveVendor: adminProcedure
      .input(z.object({ vendorId: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db.update(vendors).set({ status: "approved" }).where(eq(vendors.id, input.vendorId));
        return { success: true };
      }),

    rejectVendor: adminProcedure
      .input(z.object({ vendorId: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db.update(vendors).set({ status: "rejected" }).where(eq(vendors.id, input.vendorId));
        return { success: true };
      }),

    getTicketStats: adminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return { totalTickets: 0, totalRevenue: 0, activeTickets: 0 };

      const allTickets = await db.select().from(tickets);
      const totalTickets = allTickets.length;
      const totalRevenue = allTickets.reduce((sum, t) => sum + parseFloat(t.price.toString()), 0);
      const activeTickets = allTickets.filter(t => t.status === "active").length;

      return { totalTickets, totalRevenue, activeTickets };
    }),
  }),
});

export type AppRouter = typeof appRouter;

// Import eq for database operations
import { eq } from "drizzle-orm";
