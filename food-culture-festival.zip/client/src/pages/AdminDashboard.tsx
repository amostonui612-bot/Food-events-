import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";
import { BarChart3, Users, Ticket, TrendingUp, CheckCircle, XCircle, Clock } from "lucide-react";

export default function AdminDashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<"overview" | "vendors" | "tickets">("overview");

  // Check if user is admin
  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="p-8 text-center">
          <h1 className="text-2xl font-bold mb-4">Access Denied</h1>
          <p className="text-gray-600 mb-6">You don't have permission to access this page.</p>
          <Button onClick={() => setLocation("/")}>Go Home</Button>
        </Card>
      </div>
    );
  }

  const { data: vendors } = trpc.admin.getVendors.useQuery();
  const { data: ticketStats } = trpc.admin.getTicketStats.useQuery();
  const approveVendor = trpc.admin.approveVendor.useMutation();
  const rejectVendor = trpc.admin.rejectVendor.useMutation();

  const handleApproveVendor = async (vendorId: number) => {
    try {
      await approveVendor.mutateAsync({ vendorId });
      toast.success("Vendor approved!");
    } catch (error) {
      toast.error("Failed to approve vendor");
    }
  };

  const handleRejectVendor = async (vendorId: number) => {
    try {
      await rejectVendor.mutateAsync({ vendorId });
      toast.success("Vendor rejected");
    } catch (error) {
      toast.error("Failed to reject vendor");
    }
  };

  const pendingVendors = vendors?.filter(v => v.status === "pending") || [];
  const approvedVendors = vendors?.filter(v => v.status === "approved") || [];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Admin Dashboard</h1>
          <p className="text-gray-600">Manage vendors, view analytics, and monitor festival operations</p>
        </div>

        {/* Navigation Tabs */}
        <div className="flex gap-4 mb-8 border-b border-gray-200">
          <button
            onClick={() => setActiveTab("overview")}
            className={`px-4 py-2 font-semibold border-b-2 transition-colors ${
              activeTab === "overview"
                ? "border-orange-600 text-orange-600"
                : "border-transparent text-gray-600 hover:text-gray-900"
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab("vendors")}
            className={`px-4 py-2 font-semibold border-b-2 transition-colors ${
              activeTab === "vendors"
                ? "border-orange-600 text-orange-600"
                : "border-transparent text-gray-600 hover:text-gray-900"
            }`}
          >
            Vendors
          </button>
          <button
            onClick={() => setActiveTab("tickets")}
            className={`px-4 py-2 font-semibold border-b-2 transition-colors ${
              activeTab === "tickets"
                ? "border-orange-600 text-orange-600"
                : "border-transparent text-gray-600 hover:text-gray-900"
            }`}
          >
            Tickets
          </button>
        </div>

        {/* Overview Tab */}
        {activeTab === "overview" && (
          <div className="space-y-8">
            {/* Stats Cards */}
            <div className="grid md:grid-cols-4 gap-6">
              <Card className="p-6 border-orange-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm mb-1">Total Vendors</p>
                    <p className="text-3xl font-bold">{vendors?.length || 0}</p>
                  </div>
                  <Users className="w-12 h-12 text-orange-600 opacity-20" />
                </div>
              </Card>

              <Card className="p-6 border-orange-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm mb-1">Pending Approval</p>
                    <p className="text-3xl font-bold text-yellow-600">{pendingVendors.length}</p>
                  </div>
                  <Clock className="w-12 h-12 text-yellow-600 opacity-20" />
                </div>
              </Card>

              <Card className="p-6 border-orange-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm mb-1">Total Tickets Sold</p>
                    <p className="text-3xl font-bold">{ticketStats?.totalTickets || 0}</p>
                  </div>
                  <Ticket className="w-12 h-12 text-blue-600 opacity-20" />
                </div>
              </Card>

              <Card className="p-6 border-orange-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm mb-1">Total Revenue</p>
                    <p className="text-3xl font-bold text-green-600">${ticketStats?.totalRevenue.toFixed(2) || "0.00"}</p>
                  </div>
                  <TrendingUp className="w-12 h-12 text-green-600 opacity-20" />
                </div>
              </Card>
            </div>

            {/* Quick Stats */}
            <Card className="p-6 border-orange-200">
              <h2 className="text-2xl font-bold mb-6">Festival Overview</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <div>
                  <p className="text-gray-600 text-sm mb-2">Active Tickets</p>
                  <p className="text-4xl font-bold text-green-600">{ticketStats?.activeTickets || 0}</p>
                  <p className="text-xs text-gray-500 mt-2">Ready for entry</p>
                </div>
                <div>
                  <p className="text-gray-600 text-sm mb-2">Approved Vendors</p>
                  <p className="text-4xl font-bold text-blue-600">{approvedVendors.length}</p>
                  <p className="text-xs text-gray-500 mt-2">Ready to serve</p>
                </div>
                <div>
                  <p className="text-gray-600 text-sm mb-2">Pending Approvals</p>
                  <p className="text-4xl font-bold text-yellow-600">{pendingVendors.length}</p>
                  <p className="text-xs text-gray-500 mt-2">Awaiting review</p>
                </div>
              </div>
            </Card>
          </div>
        )}

        {/* Vendors Tab */}
        {activeTab === "vendors" && (
          <div className="space-y-8">
            {/* Pending Vendors */}
            <div>
              <h2 className="text-2xl font-bold mb-6">Pending Vendor Approvals</h2>
              {pendingVendors.length > 0 ? (
                <div className="space-y-4">
                  {pendingVendors.map((vendor) => (
                    <Card key={vendor.id} className="p-6 border-yellow-200 bg-yellow-50">
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex-1">
                          <h3 className="text-xl font-bold mb-2">{vendor.businessName}</h3>
                          <p className="text-orange-600 font-semibold mb-2">{vendor.cuisine} Cuisine</p>
                          <p className="text-gray-600 mb-2">{vendor.description}</p>
                          <div className="grid md:grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-gray-600">Contact Email:</span>
                              <p className="font-semibold">{vendor.contactEmail}</p>
                            </div>
                            {vendor.contactPhone && (
                              <div>
                                <span className="text-gray-600">Phone:</span>
                                <p className="font-semibold">{vendor.contactPhone}</p>
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="flex gap-2 ml-4">
                          <Button
                            size="sm"
                            className="bg-green-600 hover:bg-green-700"
                            onClick={() => handleApproveVendor(vendor.id)}
                            disabled={approveVendor.isPending}
                          >
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Approve
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleRejectVendor(vendor.id)}
                            disabled={rejectVendor.isPending}
                          >
                            <XCircle className="w-4 h-4 mr-2" />
                            Reject
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="p-8 text-center border-orange-200">
                  <p className="text-gray-500">No pending vendor approvals</p>
                </Card>
              )}
            </div>

            {/* Approved Vendors */}
            <div>
              <h2 className="text-2xl font-bold mb-6">Approved Vendors ({approvedVendors.length})</h2>
              {approvedVendors.length > 0 ? (
                <div className="grid md:grid-cols-2 gap-6">
                  {approvedVendors.map((vendor) => (
                    <Card key={vendor.id} className="p-6 border-green-200 bg-green-50">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="text-lg font-bold">{vendor.businessName}</h3>
                          <p className="text-orange-600 font-semibold text-sm">{vendor.cuisine}</p>
                        </div>
                        <span className="px-3 py-1 bg-green-600 text-white text-xs font-semibold rounded-full">
                          Approved
                        </span>
                      </div>
                      <div className="space-y-2 text-sm">
                        <p><span className="text-gray-600">Email:</span> {vendor.contactEmail}</p>
                        {vendor.stallNumber && (
                          <p><span className="text-gray-600">Stall:</span> #{vendor.stallNumber}</p>
                        )}
                      </div>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="p-8 text-center border-orange-200">
                  <p className="text-gray-500">No approved vendors yet</p>
                </Card>
              )}
            </div>
          </div>
        )}

        {/* Tickets Tab */}
        {activeTab === "tickets" && (
          <div className="space-y-8">
            <Card className="p-8 border-orange-200">
              <h2 className="text-2xl font-bold mb-8">Ticket Sales Analytics</h2>
              <div className="grid md:grid-cols-3 gap-8">
                <div className="text-center">
                  <BarChart3 className="w-12 h-12 text-blue-600 mx-auto mb-4 opacity-50" />
                  <p className="text-gray-600 mb-2">Total Tickets Sold</p>
                  <p className="text-4xl font-bold">{ticketStats?.totalTickets || 0}</p>
                </div>
                <div className="text-center">
                  <TrendingUp className="w-12 h-12 text-green-600 mx-auto mb-4 opacity-50" />
                  <p className="text-gray-600 mb-2">Total Revenue</p>
                  <p className="text-4xl font-bold text-green-600">${ticketStats?.totalRevenue.toFixed(2) || "0.00"}</p>
                </div>
                <div className="text-center">
                  <Ticket className="w-12 h-12 text-orange-600 mx-auto mb-4 opacity-50" />
                  <p className="text-gray-600 mb-2">Active Tickets</p>
                  <p className="text-4xl font-bold text-orange-600">{ticketStats?.activeTickets || 0}</p>
                </div>
              </div>
            </Card>

            <Card className="p-8 border-orange-200">
              <h2 className="text-xl font-bold mb-4">Ticket Scanning</h2>
              <p className="text-gray-600 mb-6">Use the ticket scanner at the entrance to validate attendee tickets.</p>
              <Button 
                className="bg-orange-600 hover:bg-orange-700"
                onClick={() => setLocation("/ticket-scanner")}
              >
                Open Ticket Scanner
              </Button>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
