import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Search, Filter, ChefHat } from "lucide-react";
import { toast } from "sonner";

const CUISINES = [
  "African",
  "Asian",
  "European",
  "Latin American",
  "Caribbean",
  "Middle Eastern",
  "American",
];

const DIETARY_PREFERENCES = [
  "Vegetarian",
  "Vegan",
  "Gluten-Free",
  "Dairy-Free",
  "Spicy",
];

export default function Marketplace() {
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCuisines, setSelectedCuisines] = useState<string[]>([]);
  const [selectedDietary, setSelectedDietary] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(false);

  const { data: vendors } = trpc.vendor.getAllApproved.useQuery();
  const { data: allMenuItems } = trpc.menu.getAll.useQuery();

  // Filter vendors based on selected cuisines
  const filteredVendors = useMemo(() => {
    if (!vendors) return [];
    
    return vendors.filter((vendor) => {
      const matchesCuisine = selectedCuisines.length === 0 || 
        selectedCuisines.some(c => vendor.cuisine.toLowerCase().includes(c.toLowerCase()));
      
      const matchesSearch = vendor.businessName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        vendor.cuisine.toLowerCase().includes(searchTerm.toLowerCase());
      
      return matchesCuisine && matchesSearch;
    });
  }, [vendors, selectedCuisines, searchTerm]);

  // Filter menu items based on dietary preferences
  const filteredMenuItems = useMemo(() => {
    if (!allMenuItems) return [];
    
    return allMenuItems.filter((item) => {
      if (selectedDietary.length === 0) return true;
      
      return selectedDietary.some(pref => 
        item.dietary?.toLowerCase().includes(pref.toLowerCase())
      );
    });
  }, [allMenuItems, selectedDietary]);

  const toggleCuisine = (cuisine: string) => {
    setSelectedCuisines(prev =>
      prev.includes(cuisine)
        ? prev.filter(c => c !== cuisine)
        : [...prev, cuisine]
    );
  };

  const toggleDietary = (dietary: string) => {
    setSelectedDietary(prev =>
      prev.includes(dietary)
        ? prev.filter(d => d !== dietary)
        : [...prev, dietary]
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-white py-12">
      <div className="container max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold mb-4">Food Marketplace</h1>
          <p className="text-gray-600">Discover authentic cuisines from around the world</p>
        </div>

        {/* Search and Filter Bar */}
        <div className="mb-8 space-y-4">
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
              <Input
                placeholder="Search vendors or cuisines..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
              className="flex gap-2"
            >
              <Filter className="w-4 h-4" />
              Filters
            </Button>
          </div>

          {/* Filter Panel */}
          {showFilters && (
            <Card className="p-6 border-orange-200">
              <div className="grid md:grid-cols-2 gap-8">
                {/* Cuisine Filter */}
                <div>
                  <h3 className="font-bold mb-4">Cuisine Type</h3>
                  <div className="space-y-2">
                    {CUISINES.map((cuisine) => (
                      <label key={cuisine} className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={selectedCuisines.includes(cuisine)}
                          onChange={() => toggleCuisine(cuisine)}
                          className="w-4 h-4 rounded border-gray-300"
                        />
                        <span className="text-sm">{cuisine}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Dietary Filter */}
                <div>
                  <h3 className="font-bold mb-4">Dietary Preferences</h3>
                  <div className="space-y-2">
                    {DIETARY_PREFERENCES.map((dietary) => (
                      <label key={dietary} className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={selectedDietary.includes(dietary)}
                          onChange={() => toggleDietary(dietary)}
                          className="w-4 h-4 rounded border-gray-300"
                        />
                        <span className="text-sm">{dietary}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              {/* Clear Filters */}
              {(selectedCuisines.length > 0 || selectedDietary.length > 0) && (
                <Button
                  variant="ghost"
                  onClick={() => {
                    setSelectedCuisines([]);
                    setSelectedDietary([]);
                  }}
                  className="mt-4 w-full"
                >
                  Clear All Filters
                </Button>
              )}
            </Card>
          )}

          {/* Active Filters Display */}
          {(selectedCuisines.length > 0 || selectedDietary.length > 0) && (
            <div className="flex flex-wrap gap-2">
              {selectedCuisines.map((cuisine) => (
                <span
                  key={cuisine}
                  className="px-3 py-1 bg-orange-100 text-orange-800 rounded-full text-sm flex items-center gap-2"
                >
                  {cuisine}
                  <button
                    onClick={() => toggleCuisine(cuisine)}
                    className="hover:text-orange-900"
                  >
                    ×
                  </button>
                </span>
              ))}
              {selectedDietary.map((dietary) => (
                <span
                  key={dietary}
                  className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm flex items-center gap-2"
                >
                  {dietary}
                  <button
                    onClick={() => toggleDietary(dietary)}
                    className="hover:text-green-900"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Vendors Grid */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold mb-6">
            Featured Vendors
            {filteredVendors.length > 0 && (
              <span className="text-gray-500 text-lg ml-2">({filteredVendors.length})</span>
            )}
          </h2>

          {filteredVendors.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredVendors.map((vendor) => (
                <Card
                  key={vendor.id}
                  className="overflow-hidden border-orange-200 hover:shadow-xl transition-shadow cursor-pointer"
                  onClick={() => setLocation(`/vendor/${vendor.id}`)}
                >
                  {vendor.image && (
                    <img
                      src={vendor.image}
                      alt={vendor.businessName}
                      className="w-full h-48 object-cover"
                    />
                  )}
                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-2">{vendor.businessName}</h3>
                    <p className="text-orange-600 font-semibold mb-2">{vendor.cuisine}</p>
                    <p className="text-gray-600 text-sm mb-4 line-clamp-2">{vendor.description}</p>
                    
                    {vendor.stallNumber && (
                      <p className="text-xs text-gray-500 mb-4">Stall #{vendor.stallNumber}</p>
                    )}

                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={(e) => {
                        e.stopPropagation();
                        setLocation(`/vendor/${vendor.id}`);
                      }}
                    >
                      View Menu
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <Card className="p-12 border-orange-200 text-center">
              <ChefHat className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 text-lg">No vendors match your filters</p>
              <Button
                variant="outline"
                onClick={() => {
                  setSelectedCuisines([]);
                  setSelectedDietary([]);
                  setSearchTerm("");
                }}
                className="mt-4"
              >
                Clear Filters
              </Button>
            </Card>
          )}
        </div>

        {/* Menu Items Section */}
        {filteredMenuItems.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold mb-6">
              Featured Menu Items
              {filteredMenuItems.length > 0 && (
                <span className="text-gray-500 text-lg ml-2">({filteredMenuItems.length})</span>
              )}
            </h2>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              {filteredMenuItems.slice(0, 12).map((item) => (
                <Card key={item.id} className="p-4 border-orange-200 hover:shadow-lg transition-shadow">
                  {item.image && (
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-32 object-cover rounded mb-3"
                    />
                  )}
                  <h4 className="font-bold mb-1">{item.name}</h4>
                  <p className="text-sm text-gray-600 mb-2 line-clamp-2">{item.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-bold text-orange-600">${item.price}</span>
                    {item.dietary && (
                      <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
                        {item.dietary}
                      </span>
                    )}
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
