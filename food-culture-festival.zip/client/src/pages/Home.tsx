import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ChefHat, MapPin, Music, Users, Utensils, Clock } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const { data: vendors } = trpc.vendor.getAllApproved.useQuery();

  const featuredVendors = vendors?.slice(0, 3) || [];

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 via-white to-amber-50">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-orange-100">
        <div className="container max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <ChefHat className="w-8 h-8 text-orange-600" />
            <span className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
              Festival
            </span>
          </div>
          <div className="flex gap-4">
            {isAuthenticated ? (
              <>
                <Button variant="outline" onClick={() => setLocation("/marketplace")}>
                  Marketplace
                </Button>
                <Button variant="outline" onClick={() => setLocation("/tickets")}>
                  My Tickets
                </Button>
                <Button variant="outline" onClick={() => setLocation("/profile")}>
                  Profile
                </Button>
              </>
            ) : (
              <Button onClick={() => setLocation("/tickets")}>
                Get Tickets
              </Button>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section - Asymmetric Layout */}
      <section className="relative overflow-hidden">
        <div className="container max-w-7xl mx-auto px-4 py-16 lg:py-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-5xl lg:text-6xl font-bold leading-tight">
                  <span className="text-gray-900">Experience the</span>
                  <br />
                  <span className="bg-gradient-to-r from-orange-600 via-red-500 to-pink-600 bg-clip-text text-transparent">
                    Flavors of the World
                  </span>
                </h1>
                <p className="text-xl text-gray-600 leading-relaxed">
                  Join thousands of food lovers at Canada's premier international food and culture festival. Discover authentic cuisines from 80+ vendors across African, Asian, European, Latin American, Caribbean, and Middle Eastern traditions.
                </p>
              </div>

              <div className="flex flex-wrap gap-3">
                <Button 
                  size="lg" 
                  className="bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white rounded-full"
                  onClick={() => setLocation("/tickets")}
                >
                  Get Tickets Now
                </Button>
                <Button 
                  size="lg" 
                  variant="outline"
                  className="rounded-full"
                  onClick={() => setLocation("/marketplace")}
                >
                  Browse Vendors
                </Button>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 pt-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-orange-600">80+</div>
                  <div className="text-sm text-gray-600">Food Vendors</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-orange-600">25K+</div>
                  <div className="text-sm text-gray-600">Attendees</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-orange-600">7</div>
                  <div className="text-sm text-gray-600">Cuisines</div>
                </div>
              </div>
            </div>

            {/* Right Visual - Asymmetric Shape */}
            <div className="relative h-96 lg:h-full min-h-96">
              <div className="absolute inset-0 bg-gradient-to-br from-orange-400/20 via-red-400/20 to-pink-400/20 rounded-3xl transform -rotate-3"></div>
              <div className="absolute inset-4 bg-gradient-to-br from-orange-300/30 via-yellow-300/20 to-red-300/30 rounded-2xl transform rotate-2"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center space-y-4">
                  <Utensils className="w-24 h-24 text-orange-600 mx-auto opacity-80" />
                  <p className="text-lg font-semibold text-gray-700">Authentic Global Cuisine</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Event Highlights */}
      <section className="py-16 bg-white border-y border-orange-100">
        <div className="container max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-12">Festival Highlights</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="p-6 border-orange-200 hover:shadow-lg transition-shadow">
              <Music className="w-12 h-12 text-orange-600 mb-4" />
              <h3 className="text-xl font-bold mb-2">Live Performances</h3>
              <p className="text-gray-600">DJ sets, cultural dance performances, and live music throughout the festival.</p>
            </Card>
            <Card className="p-6 border-orange-200 hover:shadow-lg transition-shadow">
              <MapPin className="w-12 h-12 text-orange-600 mb-4" />
              <h3 className="text-xl font-bold mb-2">Interactive Map</h3>
              <p className="text-gray-600">Navigate the festival with our interactive map showing vendor locations and rest areas.</p>
            </Card>
            <Card className="p-6 border-orange-200 hover:shadow-lg transition-shadow">
              <Users className="w-12 h-12 text-orange-600 mb-4" />
              <h3 className="text-xl font-bold mb-2">Group Bookings</h3>
              <p className="text-gray-600">Bring your friends and enjoy group discounts starting from just $10 per person.</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Featured Vendors */}
      <section className="py-16">
        <div className="container max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12">Featured Vendors</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {featuredVendors.length > 0 ? (
              featuredVendors.map((vendor) => (
                <Card 
                  key={vendor.id} 
                  className="overflow-hidden border-orange-200 hover:shadow-xl transition-shadow cursor-pointer"
                  onClick={() => setLocation(`/vendor/${vendor.id}`)}
                >
                  {vendor.image && (
                    <img 
                      src={vendor.image} 
                      alt={vendor.businessName}
                      className="w-full h-48 object-cover"
                    />
                  )}
                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-2">{vendor.businessName}</h3>
                    <p className="text-orange-600 font-semibold mb-2">{vendor.cuisine} Cuisine</p>
                    <p className="text-gray-600 text-sm mb-4">{vendor.description}</p>
                    <Button variant="outline" className="w-full" onClick={() => setLocation(`/vendor/${vendor.id}`)}>
                      View Menu
                    </Button>
                  </div>
                </Card>
              ))
            ) : (
              <div className="col-span-3 text-center py-12">
                <p className="text-gray-500">Featured vendors coming soon...</p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-16 bg-gradient-to-r from-orange-50 to-red-50">
        <div className="container max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold text-center mb-12">Ticket Pricing</h2>
          <div className="grid md:grid-cols-4 gap-6">
            <Card className="p-6 border-orange-200 text-center">
              <div className="text-3xl font-bold text-orange-600 mb-2">$20</div>
              <p className="font-semibold mb-4">Single Ticket</p>
              <p className="text-sm text-gray-600">1 person entry</p>
            </Card>
            <Card className="p-6 border-orange-200 text-center">
              <div className="text-3xl font-bold text-orange-600 mb-2">$14</div>
              <p className="font-semibold mb-4">Group (2-4)</p>
              <p className="text-sm text-gray-600">Per person</p>
            </Card>
            <Card className="p-6 border-orange-200 text-center">
              <div className="text-3xl font-bold text-orange-600 mb-2">$12</div>
              <p className="font-semibold mb-4">Group (5-9)</p>
              <p className="text-sm text-gray-600">Per person</p>
            </Card>
            <Card className="p-6 border-orange-200 text-center bg-gradient-to-br from-orange-100 to-red-100">
              <div className="text-3xl font-bold text-red-600 mb-2">$10</div>
              <p className="font-semibold mb-4">Group (10+)</p>
              <p className="text-sm text-gray-600">Per person</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Event Schedule */}
      <section className="py-16">
        <div className="container max-w-7xl mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12">Event Schedule</h2>
          <div className="space-y-4">
            <Card className="p-6 border-orange-200 flex items-start gap-4">
              <Clock className="w-6 h-6 text-orange-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-lg">10:00 AM - Opening Ceremony</h3>
                <p className="text-gray-600">Welcome speech and festival kickoff</p>
              </div>
            </Card>
            <Card className="p-6 border-orange-200 flex items-start gap-4">
              <Clock className="w-6 h-6 text-orange-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-lg">12:00 PM - Food Marketplace Opens</h3>
                <p className="text-gray-600">All vendors ready to serve authentic cuisines</p>
              </div>
            </Card>
            <Card className="p-6 border-orange-200 flex items-start gap-4">
              <Clock className="w-6 h-6 text-orange-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-lg">3:00 PM - Live Performances Begin</h3>
                <p className="text-gray-600">Cultural dance performances and live music</p>
              </div>
            </Card>
            <Card className="p-6 border-orange-200 flex items-start gap-4">
              <Clock className="w-6 h-6 text-orange-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-bold text-lg">6:00 PM - Street Food Competition</h3>
                <p className="text-gray-600">Vote for your favorite vendor</p>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-orange-600 to-red-600 text-white">
        <div className="container max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Explore Global Flavors?</h2>
          <p className="text-xl mb-8 opacity-90">Join thousands of food enthusiasts at the International Food & Culture Festival</p>
          <Button 
            size="lg"
            className="bg-white text-orange-600 hover:bg-gray-100 rounded-full font-bold"
            onClick={() => setLocation("/tickets")}
          >
            Get Your Tickets Today
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-12">
        <div className="container max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="text-white font-bold mb-4">About</h3>
              <p className="text-sm">International Food & Culture Festival bringing authentic global cuisine to Canada.</p>
            </div>
            <div>
              <h3 className="text-white font-bold mb-4">Quick Links</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white">Vendors</a></li>
                <li><a href="#" className="hover:text-white">Schedule</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-bold mb-4">Support</h3>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white">FAQ</a></li>
                <li><a href="#" className="hover:text-white">Terms</a></li>
                <li><a href="#" className="hover:text-white">Privacy</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-bold mb-4">Contact</h3>
              <p className="text-sm">w9282108@gmail.com</p>
            </div>
          </div>
          <div className="border-t border-gray-700 pt-8 text-center text-sm">
            <p>&copy; 2026 International Food & Culture Festival. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
