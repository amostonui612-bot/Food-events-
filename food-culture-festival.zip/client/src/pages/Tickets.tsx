import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";
import { QrCode, Users, User, Trash2 } from "lucide-react";

export default function Tickets() {
  const [, setLocation] = useLocation();
  const { isAuthenticated } = useAuth();
  const [ticketType, setTicketType] = useState<"single" | "group">("single");
  const [groupSize, setGroupSize] = useState(2);
  const [groupLeaderName, setGroupLeaderName] = useState("");
  const [memberNames, setMemberNames] = useState<string[]>([""]);
  const [isProcessing, setIsProcessing] = useState(false);

  const createTicket = trpc.ticket.create.useMutation();
  const getUserTickets = trpc.ticket.getUserTickets.useQuery(undefined, { enabled: isAuthenticated });

  const calculatePrice = () => {
    let pricePerPerson = 20;
    if (ticketType === "group") {
      if (groupSize >= 10) pricePerPerson = 10;
      else if (groupSize >= 5) pricePerPerson = 12;
      else if (groupSize >= 2) pricePerPerson = 14;
    }
    return pricePerPerson * (ticketType === "group" ? groupSize : 1);
  };

  const handleCreateTicket = async () => {
    if (ticketType === "group" && !groupLeaderName) {
      toast.error("Please enter group leader name");
      return;
    }

    if (ticketType === "group" && memberNames.some(name => !name.trim())) {
      toast.error("Please fill in all member names");
      return;
    }

    setIsProcessing(true);
    try {
      const result = await createTicket.mutateAsync({
        ticketType,
        groupSize: ticketType === "group" ? groupSize : 1,
        groupLeaderName,
        memberNames: ticketType === "group" ? memberNames.filter(n => n.trim()) : undefined,
      });

      toast.success("Ticket created successfully!");
      setGroupLeaderName("");
      setMemberNames([""]);
      
      // Redirect to ticket confirmation
      setLocation(`/ticket-confirmation/${result.ticketCode}`);
    } catch (error) {
      toast.error("Failed to create ticket. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const addMemberField = () => {
    setMemberNames([...memberNames, ""]);
  };

  const removeMemberField = (index: number) => {
    setMemberNames(memberNames.filter((_, i) => i !== index));
  };

  const updateMemberName = (index: number, value: string) => {
    const newNames = [...memberNames];
    newNames[index] = value;
    setMemberNames(newNames);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-white py-12">
      <div className="container max-w-4xl mx-auto px-4">
        <h1 className="text-4xl font-bold mb-4">Get Your Festival Tickets</h1>
        <p className="text-gray-600 mb-12">Choose your ticket type and secure your spot at the International Food & Culture Festival.</p>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Ticket Selection */}
          <div className="lg:col-span-2 space-y-8">
            {/* Ticket Type Selection */}
            <Card className="p-8 border-orange-200">
              <h2 className="text-2xl font-bold mb-6">Select Ticket Type</h2>
              <div className="grid md:grid-cols-2 gap-4 mb-8">
                <button
                  onClick={() => setTicketType("single")}
                  className={`p-6 rounded-lg border-2 transition-all ${
                    ticketType === "single"
                      ? "border-orange-600 bg-orange-50"
                      : "border-gray-200 hover:border-orange-300"
                  }`}
                >
                  <User className="w-8 h-8 mb-2 mx-auto text-orange-600" />
                  <h3 className="font-bold mb-2">Single Ticket</h3>
                  <p className="text-sm text-gray-600">$20 per person</p>
                </button>
                <button
                  onClick={() => setTicketType("group")}
                  className={`p-6 rounded-lg border-2 transition-all ${
                    ticketType === "group"
                      ? "border-orange-600 bg-orange-50"
                      : "border-gray-200 hover:border-orange-300"
                  }`}
                >
                  <Users className="w-8 h-8 mb-2 mx-auto text-orange-600" />
                  <h3 className="font-bold mb-2">Group Booking</h3>
                  <p className="text-sm text-gray-600">Save up to 50%</p>
                </button>
              </div>

              {/* Group Size Selector */}
              {ticketType === "group" && (
                <div className="space-y-4 mb-8 p-4 bg-orange-50 rounded-lg">
                  <div>
                    <Label className="block mb-2">Number of People</Label>
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        min="2"
                        max="100"
                        value={groupSize}
                        onChange={(e) => setGroupSize(Math.max(2, parseInt(e.target.value) || 2))}
                        className="w-24"
                      />
                      <div className="flex-1 flex items-center">
                        <div className="text-sm">
                          {groupSize >= 10 && <span className="text-green-600 font-semibold">$10/person - Best Deal!</span>}
                          {groupSize >= 5 && groupSize < 10 && <span className="text-green-600 font-semibold">$12/person - Great Deal!</span>}
                          {groupSize >= 2 && groupSize < 5 && <span className="text-blue-600 font-semibold">$14/person - Good Deal</span>}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Group Leader Name */}
                  <div>
                    <Label className="block mb-2">Group Leader Name</Label>
                    <Input
                      placeholder="Enter your name"
                      value={groupLeaderName}
                      onChange={(e) => setGroupLeaderName(e.target.value)}
                    />
                  </div>

                  {/* Member Names */}
                  <div>
                    <Label className="block mb-2">Group Member Names</Label>
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {memberNames.map((name, index) => (
                        <div key={index} className="flex gap-2">
                          <Input
                            placeholder={`Member ${index + 1}`}
                            value={name}
                            onChange={(e) => updateMemberName(index, e.target.value)}
                          />
                          {memberNames.length > 1 && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeMemberField(index)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      ))}
                    </div>
                    {memberNames.length < groupSize - 1 && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={addMemberField}
                        className="mt-2 w-full"
                      >
                        + Add Member
                      </Button>
                    )}
                  </div>
                </div>
              )}
            </Card>

            {/* Pricing Breakdown */}
            <Card className="p-8 border-orange-200">
              <h2 className="text-2xl font-bold mb-6">Pricing Breakdown</h2>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">
                    {ticketType === "single" ? "1 Ticket" : `${groupSize} Tickets`}
                  </span>
                  <span className="font-semibold">${calculatePrice()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Fees</span>
                  <span className="font-semibold">$0</span>
                </div>
                <div className="border-t-2 border-gray-200 pt-4 flex justify-between text-lg">
                  <span className="font-bold">Total</span>
                  <span className="font-bold text-orange-600">${calculatePrice()}</span>
                </div>
              </div>
            </Card>

            {/* Purchase Button */}
            <Button
              size="lg"
              className="w-full bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white rounded-lg"
              onClick={handleCreateTicket}
              disabled={isProcessing || createTicket.isPending}
            >
              {isProcessing || createTicket.isPending ? "Processing..." : "Proceed to Payment"}
            </Button>
          </div>

          {/* Order Summary Sidebar */}
          <div className="lg:col-span-1">
            <Card className="p-6 border-orange-200 sticky top-24 bg-gradient-to-br from-orange-50 to-red-50">
              <h3 className="text-xl font-bold mb-6">Order Summary</h3>
              <div className="space-y-4 mb-6">
                <div>
                  <p className="text-sm text-gray-600">Ticket Type</p>
                  <p className="font-semibold">{ticketType === "single" ? "Single" : "Group"}</p>
                </div>
                {ticketType === "group" && (
                  <div>
                    <p className="text-sm text-gray-600">Number of People</p>
                    <p className="font-semibold">{groupSize}</p>
                  </div>
                )}
                <div>
                  <p className="text-sm text-gray-600">Price per Ticket</p>
                  <p className="font-semibold">${calculatePrice() / (ticketType === "group" ? groupSize : 1)}</p>
                </div>
                <div className="border-t-2 border-orange-200 pt-4">
                  <p className="text-sm text-gray-600 mb-1">Total Amount</p>
                  <p className="text-3xl font-bold text-orange-600">${calculatePrice()}</p>
                </div>
              </div>

              {/* Features */}
              <div className="space-y-3 text-sm">
                <div className="flex gap-2">
                  <QrCode className="w-5 h-5 text-orange-600 flex-shrink-0" />
                  <span>QR Code for entry</span>
                </div>
                <div className="flex gap-2">
                  <QrCode className="w-5 h-5 text-orange-600 flex-shrink-0" />
                  <span>Email confirmation</span>
                </div>
                <div className="flex gap-2">
                  <QrCode className="w-5 h-5 text-orange-600 flex-shrink-0" />
                  <span>Mobile wallet ticket</span>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* My Tickets Section */}
        {isAuthenticated && getUserTickets.data && getUserTickets.data.length > 0 && (
          <div className="mt-16">
            <h2 className="text-3xl font-bold mb-6">Your Tickets</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {getUserTickets.data.map((ticket) => (
                <Card key={ticket.id} className="p-6 border-orange-200">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-bold text-lg">
                        {ticket.ticketType === "single" ? "Single Ticket" : `Group Ticket (${ticket.groupSize} people)`}
                      </h3>
                      <p className="text-sm text-gray-600">Code: {ticket.ticketCode}</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      ticket.status === "active" ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"
                    }`}>
                      {ticket.status}
                    </span>
                  </div>
                  {ticket.qrCode && (
                    <div className="mb-4 p-4 bg-gray-100 rounded-lg flex justify-center">
                      <img src={ticket.qrCode} alt="QR Code" className="w-32 h-32" />
                    </div>
                  )}
                  <Button variant="outline" className="w-full">
                    View Details
                  </Button>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
