import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";
import { Plus, Trash2, Edit2 } from "lucide-react";

const CUISINES = [
  "African",
  "Asian",
  "European",
  "Latin American",
  "Caribbean",
  "Middle Eastern",
  "American",
];

export default function VendorPortal() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<"profile" | "menu">("profile");
  const [isRegistering, setIsRegistering] = useState(false);

  // Form states
  const [businessName, setBusinessName] = useState("");
  const [cuisine, setCuisine] = useState("");
  const [description, setDescription] = useState("");
  const [image, setImage] = useState("");
  const [contactEmail, setContactEmail] = useState(user?.email || "");
  const [contactPhone, setContactPhone] = useState("");

  // Menu form states
  const [menuName, setMenuName] = useState("");
  const [menuDescription, setMenuDescription] = useState("");
  const [price, setPrice] = useState("");
  const [dietary, setDietary] = useState("");
  const [menuImage, setMenuImage] = useState("");

  // Queries and mutations
  const { data: vendorProfile } = trpc.vendor.getProfile.useQuery(undefined, { enabled: isAuthenticated });
  const { data: menuItems } = trpc.menu.getByVendor.useQuery(
    { vendorId: vendorProfile?.id || 0 },
    { enabled: !!vendorProfile?.id }
  );

  const registerVendor = trpc.vendor.register.useMutation();
  const updateProfile = trpc.vendor.updateProfile.useMutation();
  const addMenuItem = trpc.menu.addItem.useMutation();
  const deleteMenuItem = trpc.menu.deleteItem.useMutation();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="p-8 text-center">
          <h1 className="text-2xl font-bold mb-4">Sign In Required</h1>
          <p className="text-gray-600 mb-6">Please sign in to access the vendor portal.</p>
          <Button onClick={() => setLocation("/")}>Go Home</Button>
        </Card>
      </div>
    );
  }

  const handleRegisterVendor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!businessName || !cuisine || !contactEmail) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      await registerVendor.mutateAsync({
        businessName,
        cuisine,
        description,
        image,
        contactEmail,
        contactPhone,
      });
      toast.success("Vendor registration submitted! Awaiting admin approval.");
      setBusinessName("");
      setCuisine("");
      setDescription("");
      setImage("");
      setContactPhone("");
    } catch (error) {
      toast.error("Failed to register vendor");
    }
  };

  const handleAddMenuItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!menuName || !price) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      await addMenuItem.mutateAsync({
        name: menuName,
        description: menuDescription,
        price,
        image: menuImage,
        dietary,
      });
      toast.success("Menu item added!");
      setMenuName("");
      setMenuDescription("");
      setPrice("");
      setMenuImage("");
      setDietary("");
    } catch (error) {
      toast.error("Failed to add menu item");
    }
  };

  const handleDeleteMenuItem = async (itemId: number) => {
    if (!confirm("Are you sure you want to delete this menu item?")) return;

    try {
      await deleteMenuItem.mutateAsync({ itemId });
      toast.success("Menu item deleted");
    } catch (error) {
      toast.error("Failed to delete menu item");
    }
  };

  // If vendor doesn't exist, show registration form
  if (!vendorProfile) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-orange-50 to-white py-12">
        <div className="container max-w-2xl mx-auto px-4">
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-4">Become a Vendor</h1>
            <p className="text-gray-600">Register your food business for the International Food & Culture Festival</p>
          </div>

          <Card className="p-8 border-orange-200">
            <form onSubmit={handleRegisterVendor} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label className="block mb-2">Business Name *</Label>
                  <Input
                    placeholder="Your restaurant or food business name"
                    value={businessName}
                    onChange={(e) => setBusinessName(e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label className="block mb-2">Cuisine Type *</Label>
                  <select
                    value={cuisine}
                    onChange={(e) => setCuisine(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    required
                  >
                    <option value="">Select a cuisine</option>
                    {CUISINES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <Label className="block mb-2">Description</Label>
                <textarea
                  placeholder="Tell us about your business and cuisine"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md h-24"
                />
              </div>

              <div>
                <Label className="block mb-2">Business Image URL</Label>
                <Input
                  placeholder="https://example.com/image.jpg"
                  value={image}
                  onChange={(e) => setImage(e.target.value)}
                />
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label className="block mb-2">Contact Email *</Label>
                  <Input
                    type="email"
                    placeholder="your@email.com"
                    value={contactEmail}
                    onChange={(e) => setContactEmail(e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label className="block mb-2">Contact Phone</Label>
                  <Input
                    type="tel"
                    placeholder="+1 (555) 000-0000"
                    value={contactPhone}
                    onChange={(e) => setContactPhone(e.target.value)}
                  />
                </div>
              </div>

              <Button
                type="submit"
                size="lg"
                className="w-full bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white"
                disabled={registerVendor.isPending}
              >
                {registerVendor.isPending ? "Submitting..." : "Submit Registration"}
              </Button>

              <p className="text-sm text-gray-600 text-center">
                Your registration will be reviewed by our team. You'll receive an email confirmation once approved.
              </p>
            </form>
          </Card>
        </div>
      </div>
    );
  }

  // Vendor profile exists - show management portal
  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-white py-12">
      <div className="container max-w-4xl mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Vendor Portal</h1>
          <p className="text-gray-600">Manage your vendor profile and menu items</p>
        </div>

        {/* Status Badge */}
        <Card className="p-4 mb-8 border-orange-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Registration Status</p>
              <p className="font-bold">{vendorProfile.businessName}</p>
            </div>
            <span className={`px-4 py-2 rounded-full font-semibold text-white ${
              vendorProfile.status === "approved" ? "bg-green-600" :
              vendorProfile.status === "pending" ? "bg-yellow-600" :
              "bg-red-600"
            }`}>
              {vendorProfile.status.charAt(0).toUpperCase() + vendorProfile.status.slice(1)}
            </span>
          </div>
        </Card>

        {/* Tabs */}
        <div className="flex gap-4 mb-8 border-b border-gray-200">
          <button
            onClick={() => setActiveTab("profile")}
            className={`px-4 py-2 font-semibold border-b-2 transition-colors ${
              activeTab === "profile"
                ? "border-orange-600 text-orange-600"
                : "border-transparent text-gray-600 hover:text-gray-900"
            }`}
          >
            Profile
          </button>
          <button
            onClick={() => setActiveTab("menu")}
            className={`px-4 py-2 font-semibold border-b-2 transition-colors ${
              activeTab === "menu"
                ? "border-orange-600 text-orange-600"
                : "border-transparent text-gray-600 hover:text-gray-900"
            }`}
          >
            Menu Items
          </button>
        </div>

        {/* Profile Tab */}
        {activeTab === "profile" && (
          <Card className="p-8 border-orange-200">
            <h2 className="text-2xl font-bold mb-6">Business Profile</h2>
            <div className="space-y-4">
              <div>
                <Label className="block text-sm text-gray-600 mb-1">Business Name</Label>
                <p className="text-lg font-semibold">{vendorProfile.businessName}</p>
              </div>
              <div>
                <Label className="block text-sm text-gray-600 mb-1">Cuisine Type</Label>
                <p className="text-lg font-semibold">{vendorProfile.cuisine}</p>
              </div>
              {vendorProfile.description && (
                <div>
                  <Label className="block text-sm text-gray-600 mb-1">Description</Label>
                  <p className="text-lg">{vendorProfile.description}</p>
                </div>
              )}
              <div>
                <Label className="block text-sm text-gray-600 mb-1">Contact Email</Label>
                <p className="text-lg">{vendorProfile.contactEmail}</p>
              </div>
              {vendorProfile.contactPhone && (
                <div>
                  <Label className="block text-sm text-gray-600 mb-1">Contact Phone</Label>
                  <p className="text-lg">{vendorProfile.contactPhone}</p>
                </div>
              )}
              {vendorProfile.stallNumber && (
                <div>
                  <Label className="block text-sm text-gray-600 mb-1">Stall Number</Label>
                  <p className="text-lg font-semibold">#{vendorProfile.stallNumber}</p>
                </div>
              )}
            </div>
          </Card>
        )}

        {/* Menu Tab */}
        {activeTab === "menu" && (
          <div className="space-y-8">
            {/* Add Menu Item Form */}
            <Card className="p-8 border-orange-200">
              <h2 className="text-2xl font-bold mb-6">Add Menu Item</h2>
              <form onSubmit={handleAddMenuItem} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label className="block mb-2">Item Name *</Label>
                    <Input
                      placeholder="e.g., Jollof Rice"
                      value={menuName}
                      onChange={(e) => setMenuName(e.target.value)}
                      required
                    />
                  </div>
                  <div>
                    <Label className="block mb-2">Price *</Label>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="12.99"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label className="block mb-2">Description</Label>
                  <textarea
                    placeholder="Describe your dish"
                    value={menuDescription}
                    onChange={(e) => setMenuDescription(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md h-20"
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label className="block mb-2">Dietary Info</Label>
                    <Input
                      placeholder="e.g., Vegetarian, Vegan, Gluten-Free"
                      value={dietary}
                      onChange={(e) => setDietary(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label className="block mb-2">Image URL</Label>
                    <Input
                      placeholder="https://example.com/image.jpg"
                      value={menuImage}
                      onChange={(e) => setMenuImage(e.target.value)}
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full bg-orange-600 hover:bg-orange-700 text-white"
                  disabled={addMenuItem.isPending}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  {addMenuItem.isPending ? "Adding..." : "Add Menu Item"}
                </Button>
              </form>
            </Card>

            {/* Menu Items List */}
            <div>
              <h2 className="text-2xl font-bold mb-6">Your Menu Items</h2>
              {menuItems && menuItems.length > 0 ? (
                <div className="grid md:grid-cols-2 gap-6">
                  {menuItems.map((item) => (
                    <Card key={item.id} className="p-6 border-orange-200">
                      {item.image && (
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-full h-32 object-cover rounded mb-4"
                        />
                      )}
                      <h3 className="text-lg font-bold mb-2">{item.name}</h3>
                      <p className="text-gray-600 text-sm mb-2">{item.description}</p>
                      <div className="flex justify-between items-center mb-4">
                        <span className="text-2xl font-bold text-orange-600">${item.price}</span>
                        {item.dietary && (
                          <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
                            {item.dietary}
                          </span>
                        )}
                      </div>
                      <Button
                        variant="destructive"
                        size="sm"
                        className="w-full"
                        onClick={() => handleDeleteMenuItem(item.id)}
                        disabled={deleteMenuItem.isPending}
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </Button>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="p-8 text-center border-orange-200">
                  <p className="text-gray-500 mb-4">No menu items yet</p>
                  <p className="text-sm text-gray-600">Add your first menu item above to get started</p>
                </Card>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
